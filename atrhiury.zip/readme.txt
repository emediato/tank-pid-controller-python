Trabalho prático Final ATR. 

Autor: Hiury Goulart Sant Ana.

Procedimentos para a execução dos Programas.

Copie todos os arquivos .py para um mesmo diretório.
Copie também o arquivo "Makefile" nesse mesmo diretório.
Feito isso, abra o terminal do linux.
Use o comando 'cd' para navegar até o diretório onde estão os programas copiados.
Digite no terminal <make>.
Feito isso os programas serão compilados pelo compilador 'python'.
Terminada a compilação um gráfico referente ao funcionamento será plotado. Pronto! 
Para fechar a compilação, basta fechar o gráfico gerado.






