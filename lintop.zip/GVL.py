#GVL

actuatort1 = 0  # updated
actuatort2 = 0  # updated

levelh1 = 3  #var controllers
levelh2 = 2

outq1 = 0    #manipulated variables
outq2 = 0

legends1 = []
legends2 = []

legendsh1 = []
legendsh2 = []
